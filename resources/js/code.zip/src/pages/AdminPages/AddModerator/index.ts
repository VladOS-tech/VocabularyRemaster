import AddModerator from "./ui/AddModerator.vue";

export default AddModerator
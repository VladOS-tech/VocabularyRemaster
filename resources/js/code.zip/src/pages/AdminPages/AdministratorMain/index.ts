import AdministratorMain from "./ui/AdministratorMain.vue";

export default AdministratorMain
import AddModerator from "./AddModerator";
import AdministratorMain from "./AdministratorMain";
import EditModerator from "./EditModerator";

export default {AddModerator, AdministratorMain, EditModerator}
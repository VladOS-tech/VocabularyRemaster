import EditModerator from "./ui/EditModerator.vue";

export default EditModerator
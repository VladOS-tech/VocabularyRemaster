import LoginPage from "./ui/LoginPage.vue";

export default LoginPage
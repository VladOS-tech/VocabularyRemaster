import ModeratorMain from "./ModeratorMain";
import RequestReview from "./RequestReview";

export default {ModeratorMain, RequestReview}
import ModeratorMain from "./ui/ModeratorMain.vue";

export default ModeratorMain
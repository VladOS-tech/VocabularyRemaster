import RoleSelection from "./ui/RoleSelection.vue";

export default {RoleSelection}
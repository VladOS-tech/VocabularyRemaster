import AddPhrasePage from "./AddPhrasePage/ui/AddPhrasePage.vue";
import PhrasesPage from "./PhrasesPage/ui/PhrasesPage.vue";

export default {AddPhrasePage, PhrasesPage}
import AddPhrasePage from "./ui/AddPhrasePage.vue";

export default AddPhrasePage
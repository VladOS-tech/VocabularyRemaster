import PhrasesPage from "./ui/PhrasesPage.vue";

export default PhrasesPage
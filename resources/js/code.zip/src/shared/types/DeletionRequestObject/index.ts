type DeletionRequestObject = {
    id: string,
    created_at: Date,
    moderator_email: string,
    moderator_name: string,
    phraseology_content: string,
    reason: string
}

export default DeletionRequestObject;
type TagObject = {
    id: number,
    content: string,
    count: number
}

export default TagObject;
type LoadingObject = {
    phrases: boolean,
    tags: boolean,
    inputPhrase: boolean
}

export default LoadingObject
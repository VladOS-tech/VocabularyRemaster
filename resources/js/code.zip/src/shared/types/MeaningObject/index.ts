type MeaningObject = {
    meaning: string,
    example: string
}

export default MeaningObject;
type SortingOption = {
    displayName: string,
    name: string,
    icon: string
}

export default SortingOption
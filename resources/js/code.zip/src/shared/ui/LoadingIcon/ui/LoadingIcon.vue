<template>
    <div class="loading-icon">
        <img src="@/shared/assets/images/loading.svg" alt="">
    </div>
</template>

<script lang="ts">
    import { defineComponent } from 'vue'

    export default defineComponent({
        
    })
</script>

<style scoped>
    @import url('LoadingIcon.css');
</style>
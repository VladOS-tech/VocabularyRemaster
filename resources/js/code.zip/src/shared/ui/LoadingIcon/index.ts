import LoadingIcon from "./ui/LoadingIcon.vue";

export default LoadingIcon
import HelpBlock from "./HelpBlock";
import SidebarTags from "./SidebarTags";

export default {HelpBlock, SidebarTags}
import requestReviewForm from "./model/request-review-form";
import staffStore from "./model/staff-store";

export default {requestReviewForm, staffStore}
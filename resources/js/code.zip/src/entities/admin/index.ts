import addModeratorForm from "./model/add-moderator-form";
import editModeratorForm from "./model/edit-moderator-form";

export default {addModeratorForm, editModeratorForm}
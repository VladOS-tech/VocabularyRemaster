import AddPhraseForm from "./ui/AddPhraseForm.vue";

export default AddPhraseForm
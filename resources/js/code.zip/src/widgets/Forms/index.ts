import AddPhraseForm from "./AddPhraseForm";
import LoginForm from "./LoginForm";
import RoleSelectionForm from "./RoleSelectionForm";

export default {AddPhraseForm, LoginForm, RoleSelectionForm}
import AddModeratorForm from "./ui/AddModeratorForm.vue"

export default AddModeratorForm
import AddModeratorForm from "./AddModeratorForm";
import EditModeratorForm from "./EditModeratorForm";

export default {AddModeratorForm, EditModeratorForm}
import EditModeratorForm from "./ui/EditModeratorForm.vue"

export default EditModeratorForm
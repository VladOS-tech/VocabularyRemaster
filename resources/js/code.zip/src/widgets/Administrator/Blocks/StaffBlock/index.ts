import StaffBlock from "./ui/StaffBlock.vue";

export default StaffBlock
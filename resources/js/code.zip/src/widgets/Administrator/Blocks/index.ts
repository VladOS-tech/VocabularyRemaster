import DeletionRequestsBlock from "./DeletionRequestBlock";
import StaffBlock from "./StaffBlock";

export default {DeletionRequestsBlock, StaffBlock}
import DeletionRequestsBlock from "./ui/DeletionRequestsBlock.vue";

export default DeletionRequestsBlock
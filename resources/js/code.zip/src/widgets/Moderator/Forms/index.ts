import AddTagForm from "./AddTagForm";
import ReviewForm from "./ReviewForm";

export default {AddTagForm, ReviewForm}
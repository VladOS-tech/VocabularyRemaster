import SortingSelectionModerator from "./ui/SortingSelectionModerator.vue";

export default SortingSelectionModerator
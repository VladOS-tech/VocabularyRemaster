import SortingSelectionModerator from "./SortingSelectionModerator";

export default SortingSelectionModerator
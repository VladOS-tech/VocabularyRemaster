import TagsPage from "./ui/TagsPage.vue";

export default TagsPage
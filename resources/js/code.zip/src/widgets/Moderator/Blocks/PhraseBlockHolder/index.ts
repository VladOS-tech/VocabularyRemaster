import PhraseBlockHolder from "./ui/PhraseBlockHolder.vue";

export default PhraseBlockHolder
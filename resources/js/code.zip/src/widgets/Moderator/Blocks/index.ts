import PhraseBlockHolder from "./PhraseBlockHolder";
import RequestBlock from "./RequestBlock";
import TagsPage from "./TagsPage/ui/TagsPage.vue";

export default {PhraseBlockHolder, RequestBlock, TagsPage}
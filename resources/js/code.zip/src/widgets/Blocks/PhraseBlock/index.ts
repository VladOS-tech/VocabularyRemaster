import PhraseBlock from "./ui/PhraseBlock.vue";

export default PhraseBlock
import StaffHeader from "./StaffHeader";
import UserHeader from "./UserHeader";

export default{StaffHeader, UserHeader}
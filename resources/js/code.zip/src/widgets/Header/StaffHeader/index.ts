import StaffHeader from "./ui/StaffHeader.vue";

export default StaffHeader
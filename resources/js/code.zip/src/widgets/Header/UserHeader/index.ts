import UserHeader from "./ui/UserHeader.vue"

export default UserHeader
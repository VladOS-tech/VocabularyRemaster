import loginStore from "./model/login-store";

export default loginStore